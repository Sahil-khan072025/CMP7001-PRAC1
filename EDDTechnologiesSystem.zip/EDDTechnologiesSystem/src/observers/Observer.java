package observers;

public interface Observer {
    void update(String message);
}
